package com.math.ap.winter2022.model;

public class Airline extends User {
    public Airline(String name, String password) {
        super(name, password);
    }
}
